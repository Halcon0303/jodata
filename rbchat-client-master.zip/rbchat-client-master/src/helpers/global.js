
var scrollToOffset = null;

export default {
  scrollToOffset
};