export default {
    API_URL: "http://localhost:8080/",
    SOCKET_SUCCESS: "ok",
    TYPING_UPDATE_INTERVAL: 1000,
    NOTIFICATION_INTERVAL: 7000,

    RB_SERVER: "http://192.168.109.250/",

    logs: {
      SERVER_ERROR: "No Connection"
    }
}