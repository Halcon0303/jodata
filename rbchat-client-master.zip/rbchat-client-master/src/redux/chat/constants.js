export const CHAT_USER = "CHAT_USER";
export const ADD_LOGGED_USER = "ADD_LOGGED_USER";
export const CREATE_GROUP = "CREATE_GROUP";

export const ACTIVE_ROOM = "ACTIVE_ROOM";
export const UPDATE_ALL = "UPDATE_ALL";
export const UPDATE_ROOMS = "UPDATE_ROOMS";
export const UPDATE_USERS = "UPDATE_USERS";
export const UPDATE_WRITE_ATS = "UPDATE_WRITE_ATS";
export const INIT_CHAT = "INIT_CHAT";